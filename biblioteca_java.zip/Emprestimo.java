import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Emprestimo {
    private int codigo;
    private LocalDate dataEmprestimo;
    private boolean aberto;
    private Leitor leitor;                       // associação binária
    private ArrayList<ItemEmprestimo> itens;     // composição

    public Emprestimo(int codigo, Leitor leitor) {
        this.codigo = codigo;
        this.leitor = leitor;
        this.dataEmprestimo = LocalDate.now();
        this.aberto = true;
        this.itens = new ArrayList<>();
    }

    public int getCodigo() { return codigo; }
    public LocalDate getDataEmprestimo() { return dataEmprestimo; }
    public boolean isAberto() { return aberto; }
    public Leitor getLeitor() { return leitor; }

    // O empréstimo cria o item: o item não existe fora dele (RN09: sem repetição).
    public boolean adicionarLivro(Livro livro) {
        if (livro == null || contemLivro(livro)) return false;
        itens.add(new ItemEmprestimo(livro));
        return true;
    }

    public boolean contemLivro(Livro livro) {
        for (ItemEmprestimo item : itens)
            if (item.getLivro() == livro) return true;
        return false;
    }

    public int quantidadeItens() { return itens.size(); }

    // Encerra o empréstimo e libera cada livro (RN11, RN12).
    public void finalizar() {
        if (!aberto) return;
        for (ItemEmprestimo item : itens) {
            item.registrarDevolucao();
            item.getLivro().devolver();
        }
        aberto = false;
    }

    @Override
    public String toString() {
        StringBuilder titulos = new StringBuilder();
        for (ItemEmprestimo item : itens) {
            if (titulos.length() > 0) titulos.append(", ");
            titulos.append(item.getLivro().getTitulo());
        }
        return codigo + " - " + leitor.getNome() + " - "
                + dataEmprestimo.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                + " - " + (aberto ? "aberto" : "finalizado")
                + " - livros: " + titulos;
    }
}
