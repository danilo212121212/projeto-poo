import java.util.ArrayList;

public class Biblioteca {
    private ArrayList<Leitor> leitores = new ArrayList<>();
    private ArrayList<Livro> livros = new ArrayList<>();
    private ArrayList<Emprestimo> emprestimos = new ArrayList<>();

    // ---------- Leitores ----------
    public boolean cadastrarLeitor(Leitor leitor) {
        if (leitor == null || leitor.getCodigo() <= 0) return false;             // RN02
        if (vazio(leitor.getNome()) || vazio(leitor.getEmail())) return false;   // RN01
        if (consultarLeitor(leitor.getCodigo()) != null) return false;           // RN03
        leitores.add(leitor);
        return true;
    }

    public Leitor consultarLeitor(int codigo) {
        for (Leitor leitor : leitores)
            if (leitor.getCodigo() == codigo) return leitor;
        return null;
    }

    public void listarLeitores() {
        if (leitores.isEmpty()) {
            System.out.println("Nenhum leitor cadastrado.");
            return;
        }
        for (Leitor leitor : leitores) System.out.println(leitor);
    }

    public boolean removerLeitor(Leitor leitor) {
        if (leitor == null || !leitores.contains(leitor)) return false;
        for (Emprestimo e : emprestimos)                                         // RN13
            if (e.isAberto() && e.getLeitor() == leitor) return false;
        return leitores.remove(leitor);
    }

    // ---------- Livros ----------
    public boolean cadastrarLivro(Livro livro) {
        if (livro == null || livro.getCodigo() <= 0) return false;               // RN02
        if (vazio(livro.getTitulo()) || vazio(livro.getAutor())) return false;   // RN01
        if (consultarLivro(livro.getCodigo()) != null) return false;             // RN04
        livros.add(livro);
        return true;
    }

    public Livro consultarLivro(int codigo) {
        for (Livro livro : livros)
            if (livro.getCodigo() == codigo) return livro;
        return null;
    }

    public void listarLivros() {
        if (livros.isEmpty()) {
            System.out.println("Nenhum livro cadastrado.");
            return;
        }
        for (Livro livro : livros) System.out.println(livro);
    }

    public boolean removerLivro(Livro livro) {
        if (livro == null || !livros.contains(livro)) return false;
        for (Emprestimo e : emprestimos)                                         // RN13
            if (e.isAberto() && e.contemLivro(livro)) return false;
        return livros.remove(livro);
    }

    // ---------- Empréstimos ----------
    public boolean registrarEmprestimo(int codigo, Leitor leitor, ArrayList<Livro> livrosEscolhidos) {
        if (codigo <= 0) return false;                                           // RN02
        if (buscarEmprestimo(codigo) != null) return false;                      // RN05
        if (leitor == null || !leitores.contains(leitor)) return false;          // RN06
        if (livrosEscolhidos == null || livrosEscolhidos.isEmpty()) return false; // RN07

        // Valida tudo antes de alterar qualquer objeto.
        for (int i = 0; i < livrosEscolhidos.size(); i++) {
            Livro livro = livrosEscolhidos.get(i);
            if (livro == null || !livros.contains(livro)) return false;
            if (!livro.isDisponivel()) return false;                             // RN08
            for (int j = i + 1; j < livrosEscolhidos.size(); j++)
                if (livrosEscolhidos.get(j) == livro) return false;              // RN09
        }

        Emprestimo emprestimo = new Emprestimo(codigo, leitor);
        for (Livro livro : livrosEscolhidos) {
            emprestimo.adicionarLivro(livro);
            livro.emprestar();                                                   // RN10
        }
        emprestimos.add(emprestimo);
        return true;
    }

    public void listarEmprestimos() {
        if (emprestimos.isEmpty()) {
            System.out.println("Nenhum empréstimo registrado.");
            return;
        }
        for (Emprestimo e : emprestimos) System.out.println(e);
    }

    public boolean registrarDevolucao(int codigo) {
        Emprestimo emprestimo = buscarEmprestimo(codigo);
        if (emprestimo == null || !emprestimo.isAberto()) return false;          // RN12
        emprestimo.finalizar();
        return true;
    }

    // ---------- Auxiliares privados ----------
    private Emprestimo buscarEmprestimo(int codigo) {
        for (Emprestimo e : emprestimos)
            if (e.getCodigo() == codigo) return e;
        return null;
    }

    private boolean vazio(String texto) {
        return texto == null || texto.isBlank();
    }
}
